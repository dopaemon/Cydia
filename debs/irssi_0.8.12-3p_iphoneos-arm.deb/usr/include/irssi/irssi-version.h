/* automatically created by configure */
#define IRSSI_VERSION_DATE 20071006
#define IRSSI_VERSION_TIME 939
