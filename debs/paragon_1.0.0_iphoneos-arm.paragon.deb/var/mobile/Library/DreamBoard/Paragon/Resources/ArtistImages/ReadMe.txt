- INSTRUCTIONS -

If you want to have the artist displayed on your music tile and lockscreen instead of the album art, put a .png file after the artists name in this folder. For example, if the artist is called ”Fair to Midland”, the image file should be called ”Fair to Midland.png”. If you are using an iPhone 5, the image should be 1136px tall, otherwise 960px.